# Introduction
This is the official bot used by the [mcdiamondfire](http://www.mciamondfire.com/home) [Discord server](http://discord.gg/pDHBbBD). This discord bot's main purpose is to link new users' Discord and Minecraft accounts.

# What Verification Does
Verifying your account has multiple benifits, such as enabling "reactions." If you do not verify your account, you will not be able to send messages to any channel.

# Self Hosting
Feel free to try to self host a version of VerifyBot, but keep in mind you need a mySQL database with the proper data structure.
